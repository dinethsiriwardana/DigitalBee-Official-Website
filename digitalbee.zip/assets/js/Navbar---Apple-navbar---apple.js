
$(document).ready(function() {
    $('.navbar-toggler').on('click', function() {
        $('body').toggleClass('navbar--opened');
    });
});